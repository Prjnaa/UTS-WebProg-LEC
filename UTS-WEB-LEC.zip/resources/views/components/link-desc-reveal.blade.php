<a {{ $attributes }}>
    {{ $slot }}
</a>
