<a <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\mrvod\OneDrive - Universitas Multimedia Nusantara\Semester 3\Web Programming\UTS\UTS-WEB-LEC\resources\views/components/link-desc-reveal.blade.php ENDPATH**/ ?>