<div class="bg-white rounded-lg shadow-lg w-full object-cover aspect-square lg:flex lg:h-32 lg:w-72 ">
    <img src="<?php echo e(asset('images/menus/traditional-nasi-lemak-meal-arrangement.jpg')); ?>" alt="" class="rounded-t-lg max-h-32 sm:max-h-40 w-full lg:w-56 lg:max-h-full lg:rounded-l-lg object-cover">
    <div class="p-2">
        <h2 class="font-bold mb-1 text-lg text-slate-800 leading-6"><?php echo e($slot); ?></h2>
        <div id="price" class="font-semibold mb-1"><?php echo e($slot); ?></div>
        <p class="flex leading-3 text-xs font-light text-gray-500"><?php echo e($slot); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\mrvod\OneDrive - Universitas Multimedia Nusantara\Semester 3\Web Programming\UTS\UTS-WEB-LEC\resources\views/components/menu-item.blade.php ENDPATH**/ ?>